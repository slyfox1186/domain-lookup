from setuptools import setup

setup(
    name='domain-lookup',
    version='1.0.0',
    scripts=['domain_lookup.py'],
)